package com.example.tele2education.data.models

data class Quiz(
    var id: String = "",
    var title: String = "",
    var description: String = "",
    var form: String = "5",
    var subject: String = "",
    var picture: String = ""
)

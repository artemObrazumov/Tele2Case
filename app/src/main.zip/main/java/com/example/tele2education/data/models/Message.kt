package com.example.tele2education.data.models

data class Message(
    var id: String = "",
    var roomId: String = "",
    var authorId: String = "",
    var content: String = "",
    var authorName: String = ""
)
